
import { NgModule } from '@angular/core';  
import {Routes,RouterModule} from '@angular/router';

import { LoginComponent } from './login/login.component';
import { ForgetUserComponent } from './login/forget-user/forget-user.component';
import { ForgetPasswordComponent } from './login/forget-password/forget-password.component';
import { RegisterComponent } from './login/register/register.component';
import {SharedModule} from './shared/shared.module'

const appRoutes: Routes = [
 //{ path: '',   redirectTo: '/login', pathMatch: 'full' },
 { path: 'login', component: LoginComponent },
 //{ path: '**', component: LoginComponent },
 { path:'forgetUser' , component:ForgetUserComponent },
 { path:'forgetPassword' , component:ForgetPasswordComponent },
 { path:'register' , component:RegisterComponent },
 { path: 'requisition', loadChildren: './requisition-management/requisition/requisition.module#RequisitionModule'},
 { path: 'config', loadChildren: './configuration/configuration.module#ConfigurationModule'},
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRouting {

}

