import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-message',
  templateUrl: './message.component.html',
  styles: []
})
export class MessageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
