import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JobCodeComponent } from './job-code.component';

describe('JobCodeComponent', () => {
  let component: JobCodeComponent;
  let fixture: ComponentFixture<JobCodeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JobCodeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JobCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
