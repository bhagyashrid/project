import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-questions',
  templateUrl: './questions.component.html',
  styles: []
})
export class QuestionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
