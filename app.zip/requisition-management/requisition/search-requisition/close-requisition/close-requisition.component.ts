import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-close-requisition',
  templateUrl: './close-requisition.component.html',
  styles: []
})
export class CloseRequisitionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
