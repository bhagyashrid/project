import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CloseRequisitionComponent } from './close-requisition.component';

describe('CloseRequisitionComponent', () => {
  let component: CloseRequisitionComponent;
  let fixture: ComponentFixture<CloseRequisitionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CloseRequisitionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CloseRequisitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
