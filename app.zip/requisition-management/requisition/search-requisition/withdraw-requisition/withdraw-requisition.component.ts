import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-withdraw-requisition',
  templateUrl: './withdraw-requisition.component.html',
  styles: []
})
export class WithdrawRequisitionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
