import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-on-hold-requisition',
  templateUrl: './on-hold-requisition.component.html',
  styles: []
})
export class OnHoldRequisitionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
