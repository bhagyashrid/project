import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-view-requisition',
  templateUrl: './view-requisition.component.html',
  styles: []
})
export class ViewRequisitionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
