import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-edit-requisition',
  templateUrl: './edit-requisition.component.html',
  styles: []
})
export class EditRequisitionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
