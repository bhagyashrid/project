import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JobScrapingComponent } from './job-scraping.component';

describe('JobScrapingComponent', () => {
  let component: JobScrapingComponent;
  let fixture: ComponentFixture<JobScrapingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JobScrapingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JobScrapingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
