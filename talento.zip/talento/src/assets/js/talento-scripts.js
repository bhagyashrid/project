$(document).ready(function () {

  $('ul.is-hidden li a').click(function () {
    $('.cd-secondary-dropdown').css('display', 'none');
  });

  $(window).on("load resize", function (e) {
    var windowWidth = $(window).width();
    // alert("windowWidth");
    $('ul.cd-secondary-dropdown').css({
      'width': windowWidth - 200
    });

  });

});
/*
$(document).ready(function () {
  function resize() {
    var windowHeight = $(window).height();
    var wrapper = $(".wrapper-lg").height();
    console.log(wrapper);
    if (windowHeight < 600) {
      $(".l-footer").css("position", "relative");
      $(".l-footer").css("top", "30px");
    } else {
      $(".l-footer").css("position", "absolute");
      $(".l-footer").css("top", "initial");
    }
  }
  resize();

  $(window).resize(function () {
    resize();
  });
  $(".myBtn").click(function () {
    var inputVal = $("#inputUserName").val();
    var characterReg = /^([a-zA-Z0-9]{1,})$/;
    if (!characterReg.test(inputVal)) {
      $("#inputUserName").addClass('inputError');
      $(".alert-inputUserName").show().addClass('alert-login');
    };
    var inputVal = $("#inputPassword").val();
    var characterReg = /^([a-zA-Z0-9]{1,})$/;
    if (!characterReg.test(inputVal)) {
      $("#inputPassword").addClass('inputError');
      $(".alert-inputPassword").show().addClass('alert-login');
    }
  });
});

$(document).ready(function () {
  $(".myBtnA").click(function () {
    var inputVal = $("#inputPassword").val();
    var characterReg = /^([a-zA-Z0-9]{1,})$/;
    if (!characterReg.test(inputVal)) {
      $("#inputPassword").addClass('inputError');
      $(".alert-inputPassword").show().addClass('alert-login');
    }
  });
});

$(document).ready(function () {
  $(".myBtnB").click(function () {
    var inputVal = $("#inputUserName").val();
    var characterReg = /^([a-zA-Z0-9]{1,})$/;
    if (!characterReg.test(inputVal)) {
      $("#inputUserName").addClass('inputError');
      $(".alert-inputUserName").show().addClass('alert-login');
    }
  });
});


function resize() {
  var windowHeight = $(window).height();
  if (windowHeight < 800) {
    $(".l-footer").css("position", "relative");
    $(".l-footer").css("top", "50px");
  } else {
    $(".l-footer").css("position", "absolute");
    $(".l-footer").css("top", "initial");
  }
}
resize();

$(window).resize(function () {
  resize();
});


$(document).ready(function () {

  $(".myBtnC").click(function () {
    var inputVal = $("#inputFirstName").val();
    var characterReg = /^([a-zA-Z0-9]{1,})$/;
    if (!characterReg.test(inputVal)) {
      $("#inputFirstName").addClass('inputError');
      $(".alert-inputFirstName").show().addClass('alert-login');
    };
    var inputVal = $("#inputLastName").val();
    var characterReg = /^([a-zA-Z0-9]{1,})$/;
    if (!characterReg.test(inputVal)) {
      $("#inputLastName").addClass('inputError');
      $(".alert-inputLastName").show().addClass('alert-login');
    };
    var inputVal = $("#inputEmailAddress").val();
    var characterReg = /^([a-zA-Z0-9]{1,})$/;
    if (!characterReg.test(inputVal)) {
      $("#inputEmailAddress").addClass('inputError');
      $(".alert-inputEmailAddress").show().addClass('alert-login');
    };
    var inputVal = $("#inputPassword").val();
    var characterReg = /^([a-zA-Z0-9]{1,})$/;
    if (!characterReg.test(inputVal)) {
      $("#inputPassword").addClass('inputError');
      $(".alert-inputPassword").show().addClass('alert-login');
    };
    var inputVal = $("#inputPassword2").val();
    var characterReg = /^([a-zA-Z0-9]{1,})$/;
    if (!characterReg.test(inputVal)) {
      $("#inputPassword2").addClass('inputError');
      $(".alert-inputPassword2").show().addClass('alert-login');
    }
  });
});


*/