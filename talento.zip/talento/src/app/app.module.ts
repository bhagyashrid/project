import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MaterialModule} from '@angular/material';
import 'hammerjs';

import { AppComponent } from './app.component';
import { AppRouting } from './app.routing';

import { LoginComponent } from './login/login.component';
import { LoginModule } from './login/login.module';
import {ForgetUserComponent} from './login/forget-user/forget-user.component'
import {ForgetPasswordComponent} from './login/forget-password/forget-password.component'
import { RegisterComponent } from './login/register/register.component';
import { RequisitionManagementComponent } from './requisition-management/requisition-management.component';
import { RequisitionModule } from './requisition-management/requisition/requisition.module';
import { ConfigurationModule } from './configuration/configuration.module';

import {SharedModule} from './shared/shared.module';


@NgModule({
  declarations: [
    AppComponent, 
    LoginComponent  ,ForgetUserComponent , ForgetPasswordComponent,RegisterComponent,
    RequisitionManagementComponent,

  ],
  imports: [
    BrowserModule, BrowserAnimationsModule, MaterialModule.forRoot(),
    FormsModule,
    HttpModule, 
    RouterModule.forRoot([]),
    AppRouting,
    SharedModule ,
    ConfigurationModule,
    RequisitionModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
