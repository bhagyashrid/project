import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-shared',
  templateUrl: './shared.component.html',
  styles: []
})
export class SharedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
