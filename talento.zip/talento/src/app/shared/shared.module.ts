import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
//import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MaterialModule} from '@angular/material';

import { SharedComponent } from './shared.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { SidebarComponent } from './sidebar/sidebar.component';

@NgModule({
  imports: [
  //  BrowserModule,
 //   RouterModule,
    CommonModule,
    FormsModule,
    RouterModule.forRoot([]),
  ],
  declarations: [
    SharedComponent,
    NavbarComponent,
    FooterComponent,
    SidebarComponent   
    ],
  exports:[
     NavbarComponent,
     FooterComponent,
     SidebarComponent
    ],
 
})
export class SharedModule { }
