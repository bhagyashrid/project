import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-navbar',
  templateUrl: './navbar.component.html',
  styles: []
})
export class NavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
