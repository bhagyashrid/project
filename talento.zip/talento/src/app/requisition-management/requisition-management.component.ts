import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-requisition-management',
  templateUrl: './requisition-management.component.html'
})
export class RequisitionManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
