import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-requisition',
  templateUrl: './requisition.component.html'
})
export class RequisitionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
