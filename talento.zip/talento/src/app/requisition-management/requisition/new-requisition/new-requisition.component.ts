import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-new-requisition',
  templateUrl: './new-requisition.component.html',
  styles: []
})
export class NewRequisitionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
