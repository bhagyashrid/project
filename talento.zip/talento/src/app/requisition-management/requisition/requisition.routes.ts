import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {RequisitionComponent} from './requisition.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import {NewRequisitionComponent} from './new-requisition/new-requisition.component';;
import {SearchRequisitionComponent} from './search-requisition/search-requisition.component'
import {ApproveRequisitionComponent} from './approve-requisition/approve-requisition.component';
import {JobScrapingComponent} from './job-scraping/job-scraping.component';
import {CopyRequisitionComponent} from './search-requisition/copy-requisition/copy-requisition.component';
import {EditRequisitionComponent} from './search-requisition/edit-requisition/edit-requisition.component';
import {ViewRequisitionComponent} from './search-requisition/view-requisition/view-requisition.component';
import {WithdrawRequisitionComponent} from './search-requisition/withdraw-requisition/withdraw-requisition.component';
import {CloseRequisitionComponent} from './search-requisition/close-requisition/close-requisition.component';
import {OnHoldRequisitionComponent} from './search-requisition/on-hold-requisition/on-hold-requisition.component';

const requisitionRoutes: Routes = [
   {
    path: 'requisition',
    component: RequisitionComponent,
    children: [
    { path: 'dashboard', component: DashboardComponent},
    { path: 'new', component: NewRequisitionComponent },
    { path: 'search', component: SearchRequisitionComponent },
    { path: 'approve', component: ApproveRequisitionComponent },
    { path: 'jobscraping', component: JobScrapingComponent },
    { path: 'copy', component: CopyRequisitionComponent },
    { path: 'edit', component: EditRequisitionComponent },
    { path: 'view', component: ViewRequisitionComponent },
    { path: 'withdraw', component: WithdrawRequisitionComponent },
    { path: 'close', component: CloseRequisitionComponent },
    { path: 'hold', component: OnHoldRequisitionComponent },
     
    ]
  }
];


@NgModule({
  imports: [
    RouterModule.forChild(requisitionRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [

  ]
})
export class RequisitionRoutingModule { }
