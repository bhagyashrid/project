import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-approve-requisition',
  templateUrl: './approve-requisition.component.html',
  styles: []
})
export class ApproveRequisitionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
