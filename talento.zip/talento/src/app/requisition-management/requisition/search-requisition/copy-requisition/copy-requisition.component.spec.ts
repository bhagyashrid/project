import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CopyRequisitionComponent } from './copy-requisition.component';

describe('CopyRequisitionComponent', () => {
  let component: CopyRequisitionComponent;
  let fixture: ComponentFixture<CopyRequisitionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CopyRequisitionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CopyRequisitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
