import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-copy-requisition',
  templateUrl: './copy-requisition.component.html',
  styles: []
})
export class CopyRequisitionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
