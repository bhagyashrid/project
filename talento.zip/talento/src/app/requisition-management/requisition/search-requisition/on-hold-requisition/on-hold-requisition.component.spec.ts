import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnHoldRequisitionComponent } from './on-hold-requisition.component';

describe('OnHoldRequisitionComponent', () => {
  let component: OnHoldRequisitionComponent;
  let fixture: ComponentFixture<OnHoldRequisitionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnHoldRequisitionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnHoldRequisitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
