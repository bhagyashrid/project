import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WithdrawRequisitionComponent } from './withdraw-requisition.component';

describe('WithdrawRequisitionComponent', () => {
  let component: WithdrawRequisitionComponent;
  let fixture: ComponentFixture<WithdrawRequisitionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WithdrawRequisitionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WithdrawRequisitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
