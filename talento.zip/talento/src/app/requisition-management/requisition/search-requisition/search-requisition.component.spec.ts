import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchRequisitionComponent } from './search-requisition.component';

describe('SearchRequisitionComponent', () => {
  let component: SearchRequisitionComponent;
  let fixture: ComponentFixture<SearchRequisitionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchRequisitionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchRequisitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
