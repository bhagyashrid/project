import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-search-requisition',
  templateUrl: './search-requisition.component.html',
  styles: []
})
export class SearchRequisitionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
