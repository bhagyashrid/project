import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-job-scraping',
  templateUrl: './job-scraping.component.html',
  styles: []
})
export class JobScrapingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
