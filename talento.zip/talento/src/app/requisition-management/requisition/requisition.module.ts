import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';

import {SharedModule} from '../../shared/shared.module';

import { RequisitionComponent } from './requisition.component';
import { ApproveRequisitionComponent } from './approve-requisition/approve-requisition.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { JobScrapingComponent } from './job-scraping/job-scraping.component';
import { NewRequisitionComponent } from './new-requisition/new-requisition.component';
import { SearchRequisitionComponent } from './search-requisition/search-requisition.component';
import { CopyRequisitionComponent } from './search-requisition/copy-requisition/copy-requisition.component';
import { EditRequisitionComponent } from './search-requisition/edit-requisition/edit-requisition.component';
import { ViewRequisitionComponent } from './search-requisition/view-requisition/view-requisition.component';
import { WithdrawRequisitionComponent } from './search-requisition/withdraw-requisition/withdraw-requisition.component';
import { CloseRequisitionComponent } from './search-requisition/close-requisition/close-requisition.component';
import { OnHoldRequisitionComponent } from './search-requisition/on-hold-requisition/on-hold-requisition.component';

import { RequisitionRoutingModule } from './requisition.routes';

@NgModule({
  imports: [
      CommonModule,
      FormsModule,
      HttpModule, 
      SharedModule,
      RequisitionRoutingModule,
  ],
  declarations: [
    RequisitionComponent,
    ApproveRequisitionComponent,
    DashboardComponent,
    JobScrapingComponent,
    NewRequisitionComponent,
    SearchRequisitionComponent,
    CopyRequisitionComponent,
    EditRequisitionComponent,
    ViewRequisitionComponent,
    WithdrawRequisitionComponent,
    CloseRequisitionComponent,
    OnHoldRequisitionComponent],
    
  exports :[
    ApproveRequisitionComponent,
    DashboardComponent,
    JobScrapingComponent,
    NewRequisitionComponent,
    SearchRequisitionComponent,
    CopyRequisitionComponent,
    EditRequisitionComponent,
    ViewRequisitionComponent,
    WithdrawRequisitionComponent,
    CloseRequisitionComponent,
    OnHoldRequisitionComponent

  ]
})
export class RequisitionModule { }
