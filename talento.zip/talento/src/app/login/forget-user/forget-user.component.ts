import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-forget-user',
  templateUrl: './forget-user.component.html',
   styleUrls: ['../login.component.css']
})
export class ForgetUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
