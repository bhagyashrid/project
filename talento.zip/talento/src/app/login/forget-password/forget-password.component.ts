import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-forget-password',
  templateUrl: './forget-password.component.html',
    styleUrls: ['../login.component.css']
})
export class ForgetPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
