import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'tal-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'tal works!';
}
