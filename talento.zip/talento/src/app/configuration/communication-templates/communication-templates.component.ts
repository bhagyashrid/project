import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-communication-templates',
  templateUrl: './communication-templates.component.html',
  styles: []
})
export class CommunicationTemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
