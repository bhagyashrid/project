import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-configuration',
  templateUrl: './configuration.component.html'
})
export class ConfigurationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
