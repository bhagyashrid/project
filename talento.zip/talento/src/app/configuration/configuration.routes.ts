import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {ConfigurationComponent} from './configuration.component';
import { OrganizationComponent } from './organization/organization.component';
import { CensusCodeComponent } from './organization/census-code/census-code.component';
import { DecksComponent } from './organization/decks/decks.component';
import { DepartmentComponent } from './organization/department/department.component';
import { DivisionComponent } from './organization/division/division.component';
import { EformComponent } from './organization/eform/eform.component';
import { JobCodeComponent } from './organization/job-code/job-code.component';
import { JobGradeComponent } from './organization/job-grade/job-grade.component';
import { LocationComponent } from './organization/location/location.component';
import { QuestionsComponent } from './organization/questions/questions.component';
import { ProjectComponent } from './organization/project/project.component';
import { CommunicationTemplatesComponent } from './communication-templates/communication-templates.component';
import { MessageComponent } from './communication-templates/message/message.component';
import { VendorComponent } from './vendor/vendor.component';



const configRoutes: Routes = [
   {
    path: 'config',
    component: ConfigurationComponent,
    children: [
    { path: 'census', component: CensusCodeComponent},
    { path: 'decks', component: DecksComponent},
    { path: 'department', component: DepartmentComponent},
    { path: 'division', component: DivisionComponent},
    { path: 'eform', component: EformComponent},
    { path: 'jobCode', component: JobCodeComponent},
    { path: 'jobGrade', component: JobGradeComponent},
    { path: 'location', component: LocationComponent},
    { path: 'project', component: ProjectComponent},
    { path: 'questions', component: QuestionsComponent},
    { path: 'message', component: MessageComponent},
     
    ]
  }
];


@NgModule({
  imports: [
    RouterModule.forChild(configRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [

  ]
})
export class ConfigurationRoutingModule { }









