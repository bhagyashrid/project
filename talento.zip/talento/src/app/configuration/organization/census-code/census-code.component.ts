import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-census-code',
  templateUrl: './census-code.component.html',
  styles: []
})
export class CensusCodeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
