import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-job-grade',
  templateUrl: './job-grade.component.html',
  styles: []
})
export class JobGradeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
