import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-eform',
  templateUrl: './eform.component.html',
  styles: []
})
export class EformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
