import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-decks',
  templateUrl: './decks.component.html',
  styles: []
})
export class DecksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
