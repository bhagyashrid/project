import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-project',
  templateUrl: './project.component.html',
  styles: []
})
export class ProjectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
