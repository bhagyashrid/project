import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-location',
  templateUrl: './location.component.html',
  styles: []
})
export class LocationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
