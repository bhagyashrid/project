import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-division',
  templateUrl: './division.component.html',
  styles: []
})
export class DivisionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
