import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-job-code',
  templateUrl: './job-code.component.html',
  styles: []
})
export class JobCodeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
