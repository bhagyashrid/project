import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-department',
  templateUrl: './department.component.html',
  styles: []
})
export class DepartmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
