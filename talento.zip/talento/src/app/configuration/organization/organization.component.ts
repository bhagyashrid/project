import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tal-organization',
  templateUrl: './organization.component.html',
  styles: []
})
export class OrganizationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
