import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MaterialModule} from '@angular/material';
import 'hammerjs';

import {SharedModule} from '../shared/shared.module';

import {ConfigurationComponent} from './configuration.component';
import { OrganizationComponent } from './organization/organization.component';
import { CensusCodeComponent } from './organization/census-code/census-code.component';
import { DecksComponent } from './organization/decks/decks.component';
import { DepartmentComponent } from './organization/department/department.component';
import { DivisionComponent } from './organization/division/division.component';
import { EformComponent } from './organization/eform/eform.component';
import { JobCodeComponent } from './organization/job-code/job-code.component';
import { JobGradeComponent } from './organization/job-grade/job-grade.component';
import { LocationComponent } from './organization/location/location.component';
import { QuestionsComponent } from './organization/questions/questions.component';
import { ProjectComponent } from './organization/project/project.component';
import { CommunicationTemplatesComponent } from './communication-templates/communication-templates.component';
import { MessageComponent } from './communication-templates/message/message.component';
import { VendorComponent } from './vendor/vendor.component';

import { ConfigurationRoutingModule } from './configuration.routes';


@NgModule({
  imports: [
    BrowserModule,
    CommonModule,
    BrowserAnimationsModule,
    MaterialModule.forRoot(),
    FormsModule,
    HttpModule, 
    RouterModule.forRoot([]),
    SharedModule,
    ConfigurationRoutingModule
  ],
  declarations: [
    ConfigurationComponent,
    OrganizationComponent,
    CensusCodeComponent,
    DecksComponent,
    DepartmentComponent,
    DivisionComponent,
    EformComponent,
    JobCodeComponent,
    JobGradeComponent,
    LocationComponent,
    QuestionsComponent,
    ProjectComponent,
    CommunicationTemplatesComponent,
    MessageComponent,
    VendorComponent
    ]
})
export class ConfigurationModule { }
