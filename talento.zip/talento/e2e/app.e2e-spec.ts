import { TalentoPage } from './app.po';

describe('talento App', () => {
  let page: TalentoPage;

  beforeEach(() => {
    page = new TalentoPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('tal works!');
  });
});
