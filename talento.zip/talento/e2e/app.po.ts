import { browser, element, by } from 'protractor';

export class TalentoPage {
  navigateTo() {
    return browser.get('/');
  }

  getParagraphText() {
    return element(by.css('tal-root h1')).getText();
  }
}
